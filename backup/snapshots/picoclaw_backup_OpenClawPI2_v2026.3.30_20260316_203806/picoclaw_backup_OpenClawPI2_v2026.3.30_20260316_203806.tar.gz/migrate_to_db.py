"""
migrate_to_db.py — One-shot migration of picoclaw JSON/file data → SQLite.

Run ONCE on the Pi after deploying bot_db.py for the first time:

  python3 /home/stas/.picoclaw/migrate_to_db.py --source /home/stas/.picoclaw

IDEMPOTENT: safe to run multiple times (uses INSERT OR IGNORE / INSERT OR REPLACE).
Does NOT modify or delete any source files.

Exit codes:
  0 — all sections completed without errors
  1 — some sections had non-fatal errors (data still intact in source files)
  2 — fatal: DB init failed, no migration attempted
"""

from __future__ import annotations

import argparse
import json
import os
import sqlite3
import stat
import sys
import time
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Standalone schema (copy of bot_db.py's _SCHEMA_SQL so this script
# has zero imports from the bot codebase)
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS registrations (
    chat_id     INTEGER PRIMARY KEY,
    username    TEXT    DEFAULT '',
    first_name  TEXT    DEFAULT '',
    last_name   TEXT    DEFAULT '',
    name        TEXT    DEFAULT '',
    timestamp   TEXT    DEFAULT '',
    status      TEXT    NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS notes (
    chat_id  INTEGER NOT NULL,
    slug     TEXT    NOT NULL,
    title    TEXT    DEFAULT '',
    content  TEXT    DEFAULT '',
    mtime    TEXT    DEFAULT '',
    PRIMARY KEY (chat_id, slug)
);
CREATE TABLE IF NOT EXISTS calendar_events (
    id                TEXT    NOT NULL,
    chat_id           INTEGER NOT NULL,
    title             TEXT    DEFAULT '',
    dt_iso            TEXT    DEFAULT '',
    remind_before_min INTEGER NOT NULL DEFAULT 15,
    reminded          INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (id, chat_id)
);
CREATE INDEX IF NOT EXISTS idx_cal_chat ON calendar_events (chat_id, dt_iso);
CREATE TABLE IF NOT EXISTS mail_creds (
    chat_id      INTEGER PRIMARY KEY,
    provider     TEXT    DEFAULT '',
    email        TEXT    DEFAULT '',
    app_password TEXT    DEFAULT '',
    imap_host    TEXT    DEFAULT '',
    imap_port    INTEGER NOT NULL DEFAULT 993,
    spam_folder  TEXT    DEFAULT '[Gmail]/Spam',
    last_digest  TEXT    DEFAULT ''
);
CREATE TABLE IF NOT EXISTS voice_opts (
    id                  INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    silence_strip       INTEGER NOT NULL DEFAULT 0,
    low_sample_rate     INTEGER NOT NULL DEFAULT 0,
    warm_piper          INTEGER NOT NULL DEFAULT 0,
    parallel_tts        INTEGER NOT NULL DEFAULT 0,
    user_audio_toggle   INTEGER NOT NULL DEFAULT 0,
    tmpfs_model         INTEGER NOT NULL DEFAULT 0,
    vad_prefilter       INTEGER NOT NULL DEFAULT 0,
    whisper_stt         INTEGER NOT NULL DEFAULT 0,
    vosk_fallback       INTEGER NOT NULL DEFAULT 1,
    piper_low_model     INTEGER NOT NULL DEFAULT 0,
    persistent_piper    INTEGER NOT NULL DEFAULT 0,
    voice_timing_debug  INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS guest_users (
    chat_id INTEGER PRIMARY KEY
);
CREATE TABLE IF NOT EXISTS app_state (
    key   TEXT PRIMARY KEY,
    value TEXT DEFAULT ''
);
"""

_VOICE_OPT_KEYS = [
    "silence_strip", "low_sample_rate", "warm_piper", "parallel_tts",
    "user_audio_toggle", "tmpfs_model", "vad_prefilter", "whisper_stt",
    "vosk_fallback", "piper_low_model", "persistent_piper", "voice_timing_debug",
]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ok(msg: str) -> None:
    print(f"  [OK] {msg}")

def _warn(msg: str) -> None:
    print(f"  [WARN] {msg}")

def _err(msg: str) -> None:
    print(f"  [FAIL] {msg}")

def _skip(msg: str) -> None:
    print(f"  \033[90m-\033[0m {msg}")


def _open_db(db_path: str) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript("PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;")
    conn.executescript(_SCHEMA_SQL)
    conn.execute("INSERT OR IGNORE INTO voice_opts(id) VALUES(1)")
    conn.commit()
    return conn


# ---------------------------------------------------------------------------
# Migration sections
# ---------------------------------------------------------------------------

def migrate_registrations(conn: sqlite3.Connection, source: Path) -> int:
    """Migrate registrations.json → registrations table."""
    print("\n>>  registrations.json")
    reg_file = source / "registrations.json"
    if not reg_file.exists():
        _skip("File not found — OK if no users have registered yet")
        return 0
    try:
        data = json.loads(reg_file.read_text(encoding="utf-8"))
        regs = data.get("registrations", [])
    except Exception as e:
        _err(f"Cannot read file: {e}")
        return 1

    n = 0
    for r in regs:
        try:
            conn.execute(
                """INSERT OR REPLACE INTO registrations
                   (chat_id, username, first_name, last_name, name, timestamp, status)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (r.get("chat_id", 0), r.get("username", ""),
                 r.get("first_name", ""), r.get("last_name", ""),
                 r.get("name", ""), r.get("timestamp", ""),
                 r.get("status", "pending")),
            )
            n += 1
        except Exception as e:
            _warn(f"Row skipped (chat_id={r.get('chat_id')}): {e}")
    conn.commit()
    _ok(f"{n} registrations migrated")
    return 0


def migrate_guest_users(conn: sqlite3.Connection, source: Path) -> int:
    """Migrate users.json → guest_users table."""
    print("\n>>  users.json (guest users)")
    users_file = source / "users.json"
    if not users_file.exists():
        _skip("File not found — no guest users configured")
        return 0
    try:
        data = json.loads(users_file.read_text(encoding="utf-8"))
        users = {int(x) for x in data.get("users", [])}
    except Exception as e:
        _err(f"Cannot read file: {e}")
        return 1

    conn.execute("DELETE FROM guest_users")
    for uid in sorted(users):
        try:
            conn.execute("INSERT OR IGNORE INTO guest_users(chat_id) VALUES(?)", (uid,))
        except Exception as e:
            _warn(f"User {uid} skipped: {e}")
    conn.commit()
    _ok(f"{len(users)} guest users migrated")
    return 0


def migrate_voice_opts(conn: sqlite3.Connection, source: Path) -> int:
    """Migrate voice_opts.json → voice_opts table."""
    print("\n>>  voice_opts.json")
    opts_file = source / "voice_opts.json"
    if not opts_file.exists():
        _skip("File not found — defaults will be used")
        return 0
    try:
        opts = json.loads(opts_file.read_text(encoding="utf-8"))
    except Exception as e:
        _err(f"Cannot read file: {e}")
        return 1

    try:
        set_clause = ", ".join(f"{k}=?" for k in _VOICE_OPT_KEYS)
        vals       = [int(bool(opts.get(k, False))) for k in _VOICE_OPT_KEYS]
        conn.execute(f"UPDATE voice_opts SET {set_clause} WHERE id=1", vals)
        conn.commit()
        active = [k for k in _VOICE_OPT_KEYS if opts.get(k)]
        _ok(f"Voice opts migrated (active: {active or 'none'})")
    except Exception as e:
        _err(f"DB write failed: {e}")
        return 1
    return 0


def migrate_calendar(conn: sqlite3.Connection, source: Path) -> int:
    """Migrate calendar/<chat_id>.json files → calendar_events table."""
    print("\n>>  calendar/")
    cal_dir = source / "calendar"
    if not cal_dir.exists():
        _skip("Directory not found — no calendar events")
        return 0

    users, events_total, errors = 0, 0, 0
    for json_file in sorted(cal_dir.glob("*.json")):
        try:
            chat_id = int(json_file.stem)
        except ValueError:
            _warn(f"Skipping unexpected file: {json_file.name}")
            continue
        try:
            events = json.loads(json_file.read_text(encoding="utf-8"))
        except Exception as e:
            _warn(f"{json_file.name}: cannot parse — {e}")
            errors += 1
            continue

        conn.execute("DELETE FROM calendar_events WHERE chat_id=?", (chat_id,))
        for ev in events:
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO calendar_events
                       (id, chat_id, title, dt_iso, remind_before_min, reminded)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (ev.get("id", ""), chat_id, ev.get("title", ""),
                     ev.get("dt_iso", ""), int(ev.get("remind_before_min", 15)),
                     1 if ev.get("reminded") else 0),
                )
                events_total += 1
            except Exception as e:
                _warn(f"Event {ev.get('id')} for user {chat_id} skipped: {e}")
                errors += 1
        users += 1

    conn.commit()
    _ok(f"{events_total} events for {users} users migrated" +
        (f" ({errors} skipped)" if errors else ""))
    return 0


def migrate_notes(conn: sqlite3.Connection, source: Path) -> int:
    """Migrate notes/<chat_id>/*.md files → notes table."""
    print("\n>>  notes/")
    notes_dir = source / "notes"
    if not notes_dir.exists():
        _skip("Directory not found — no notes")
        return 0

    users, notes_total, errors = 0, 0, 0
    for user_dir in sorted(notes_dir.iterdir()):
        if not user_dir.is_dir():
            continue
        try:
            chat_id = int(user_dir.name)
        except ValueError:
            continue

        for md_file in sorted(user_dir.glob("*.md")):
            slug = md_file.stem
            try:
                content = md_file.read_text(encoding="utf-8")
                title   = (content.splitlines()[0].lstrip("# ").strip()
                           if content.strip() else slug)
                mtime   = str(md_file.stat().st_mtime)
                conn.execute(
                    """INSERT OR REPLACE INTO notes(chat_id, slug, title, content, mtime)
                       VALUES (?, ?, ?, ?, ?)""",
                    (chat_id, slug, title, content, mtime),
                )
                notes_total += 1
            except Exception as e:
                _warn(f"Note '{slug}' for user {chat_id} skipped: {e}")
                errors += 1
        users += 1

    conn.commit()
    _ok(f"{notes_total} notes for {users} users migrated" +
        (f" ({errors} skipped)" if errors else ""))
    return 0


def migrate_mail_creds(conn: sqlite3.Connection, source: Path) -> int:
    """Migrate mail_creds/<chat_id>.json files → mail_creds table."""
    print("\n>>  mail_creds/")
    creds_dir = source / "mail_creds"
    if not creds_dir.exists():
        _skip("Directory not found — no mail credentials")
        return 0

    n, errors = 0, 0
    for json_file in sorted(creds_dir.glob("*.json")):
        # Skip _last_digest.json and _target.json sidecars
        if "_" in json_file.stem:
            continue
        try:
            chat_id = int(json_file.stem)
        except ValueError:
            continue
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
        except Exception as e:
            _warn(f"{json_file.name}: cannot parse — {e}")
            errors += 1
            continue

        # optional: read last_digest sidecar
        last_digest_file = creds_dir / f"{chat_id}_last_digest.txt"
        last_digest = ""
        if last_digest_file.exists():
            try:
                last_digest = last_digest_file.read_text(encoding="utf-8")[:400]
            except Exception:
                pass

        try:
            conn.execute(
                """INSERT OR REPLACE INTO mail_creds
                   (chat_id, provider, email, app_password, imap_host, imap_port,
                    spam_folder, last_digest)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (chat_id, data.get("provider", ""), data.get("email", ""),
                 data.get("app_password", ""), data.get("imap_host", ""),
                 int(data.get("imap_port", 993)), data.get("spam_folder", ""),
                 last_digest),
            )
            n += 1
        except Exception as e:
            _warn(f"Creds for user {chat_id} skipped: {e}")
            errors += 1

    conn.commit()
    _ok(f"{n} mail credentials migrated" +
        (f" ({errors} skipped)" if errors else ""))
    return 0


def migrate_last_notified(conn: sqlite3.Connection, source: Path) -> int:
    """Migrate last_notified_version.txt → app_state table."""
    print("\n>>  last_notified_version.txt")
    notified_file = source / "last_notified_version.txt"
    if not notified_file.exists():
        _skip("File not found — OK, will be created on next bot start")
        return 0
    try:
        version = notified_file.read_text(encoding="utf-8").strip()
        conn.execute(
            "INSERT OR REPLACE INTO app_state(key, value) VALUES(?, ?)",
            ("last_notified_version", version),
        )
        conn.commit()
        _ok(f"last_notified_version = {version!r}")
    except Exception as e:
        _err(f"Failed: {e}")
        return 1
    return 0


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------

def verify(conn: sqlite3.Connection) -> None:
    print("\n>>  Verification")
    tables = ["registrations", "notes", "calendar_events", "mail_creds",
              "voice_opts", "guest_users", "app_state"]
    for t in tables:
        count = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        _ok(f"{t:<22}  {count:>5} row(s)")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Migrate picoclaw JSON/file data to SQLite (idempotent)"
    )
    parser.add_argument(
        "--source", "-s",
        default=os.path.expanduser("~/.picoclaw"),
        help="Path to ~/.picoclaw (default: ~/\u200b.picoclaw)",
    )
    parser.add_argument(
        "--db", "-d",
        default=None,
        help="Override DB path (default: <source>/picoclaw.db)",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Parse files but do not write to DB",
    )
    args = parser.parse_args()

    source  = Path(args.source).expanduser().resolve()
    db_path = args.db or str(source / "picoclaw.db")

    print(f"\nPicoclaw data migration")
    print(f"  Source : {source}")
    print(f"  DB     : {db_path}")
    print(f"  Mode   : {'DRY RUN' if args.dry_run else 'live (idempotent)'}")

    if not source.exists():
        print(f"\n\033[31m[ERROR]\033[0m Source directory not found: {source}")
        return 2

    if args.dry_run:
        print("\n[DRY RUN] Files will be parsed but nothing written to DB.\n")
        # Open in-memory DB for dry run
        db_path = ":memory:"

    try:
        conn = _open_db(db_path)
    except Exception as e:
        print(f"\n\033[31m[FATAL]\033[0m Cannot init DB: {e}")
        return 2

    errors = 0
    errors += migrate_registrations(conn, source)
    errors += migrate_guest_users(conn, source)
    errors += migrate_voice_opts(conn, source)
    errors += migrate_calendar(conn, source)
    errors += migrate_notes(conn, source)
    errors += migrate_mail_creds(conn, source)
    errors += migrate_last_notified(conn, source)
    verify(conn)
    conn.close()

    print()
    if errors:
        print(f"\033[33m[WARN]\033[0m Migration completed with {errors} non-fatal error(s). "
              "Source files are untouched — data is safe.")
        print("MIGRATION_PARTIAL\n")
        return 1
    else:
        print("\033[32m[OK]\033[0m All sections migrated successfully.")
        print("MIGRATION_OK\n")
        return 0


if __name__ == "__main__":
    sys.exit(main())
